import express from 'express';
import bodyParser from 'body-parser';
import fs from 'fs';

const app = express();
const PORT = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

const tasksFile = './tasks.json';
const completedFile = './completed.json';

const readJsonFile = (filePath) => {
  try {
    const data = fs.readFileSync(filePath);
    return JSON.parse(data);
  } catch (err) {
    return [];
  }
};

const writeJsonFile = (filePath, data) => {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
};

let tasks = readJsonFile(tasksFile);
let completedTasks = readJsonFile(completedFile);

app.get('/', (req, res) => {
  res.render('index', { tasks });
});

app.post('/add-task', (req, res) => {
  const { title, description, time } = req.body;
  const newTask = { title, description, time };
  tasks.push(newTask);
  writeJsonFile(tasksFile, tasks);
  res.redirect('/');
});

app.post('/complete-task', (req, res) => {
  const index = req.body.taskIndex;
  const task = tasks.splice(index, 1)[0];
  completedTasks.push(task);
  writeJsonFile(tasksFile, tasks);
  writeJsonFile(completedFile, completedTasks);
  res.redirect('/');
});

app.get('/completed', (req, res) => {
  res.render('completed', { completedTasks });
});

app.post('/delete-task', (req, res) => {
  const index = req.body.taskIndex;
  completedTasks.splice(index, 1);
  writeJsonFile(completedFile, completedTasks);
  res.redirect('/completed');
});

app.all('*', (req, res) => {
  res.status(404).render('404');
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});